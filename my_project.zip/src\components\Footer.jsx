import React from 'react';
import logo from '../assets/logo.png';
import './Footer.css';
import '../index.css';

const Footer = () => {
    return (
        <footer className="footer">
            <div className="container">
                <div className="footer-top">
                    <div className="footer-brand">
                        <img src={logo} alt="AURAC" className="footer-logo-img" />
                        <p className="footer-desc">Good ideas deserve good execution.</p>
                    </div>

                    <div className="footer-info">
                        <div className="footer-block">
                            <h4>Location</h4>
                            <p>India</p>
                        </div>
                        <div className="footer-block">
                            <h4>Contact</h4>
                            <a href="mailto:auraofaurac@gmail.com">auraofaurac@gmail.com</a>
                        </div>
                        <div className="footer-block">
                            <h4>Social</h4>
                            <div className="social-links">
                                <a href="#">Instagram</a>
                                <a href="#">YouTube</a>
                                <a href="#">LinkedIn</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="footer-bottom">
                    <p>&copy; Aurac. All rights reserved.</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
