import React from 'react';
import { motion } from 'framer-motion';
import logo from '../assets/logo.png';
import './Hero.css';

const Hero = () => {
    const fadeUp = {
        hidden: { opacity: 0, y: 30 },
        visible: (i = 0) => ({
            opacity: 1,
            y: 0,
            transition: {
                duration: 0.8,
                delay: 0.2 + i * 0.1,
                ease: [0.22, 1, 0.36, 1]
            }
        })
    };

    return (
        <section className="hero" id="hero">
            <div className="hero-background-glow"></div>
            <div className="container hero-container">
                <div className="hero-content">
                    <motion.div
                        custom={0}
                        initial="hidden"
                        animate="visible"
                        variants={fadeUp}
                        className="hero-logo-wrapper"
                    >
                        <img src={logo} alt="AURAC Logo" className="hero-logo" />
                    </motion.div>

                    <div className="hero-title-wrapper">
                        <motion.h1
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
                            className="hero-title-line"
                        >
                            Full-Stack Digital & <span className="text-highlight">Creative Studio</span>
                        </motion.h1>
                    </div>

                    <motion.p
                        custom={2}
                        initial="hidden"
                        animate="visible"
                        variants={fadeUp}
                        className="hero-description"
                    >
                        Web, design, marketing, branding, and storytelling — all in one studio.
                    </motion.p>

                    <motion.div
                        custom={3}
                        initial="hidden"
                        animate="visible"
                        variants={fadeUp}
                        className="hero-actions"
                    >
                        <button className="primary-btn" onClick={() => document.getElementById('contact').scrollIntoView({ behavior: 'smooth' })}>
                            Let’s Talk
                        </button>
                    </motion.div>
                </div>
            </div>
        </section>
    );
};

export default Hero;
