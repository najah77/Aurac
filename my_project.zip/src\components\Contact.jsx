import React from 'react';
import { motion } from 'framer-motion';
import './Section.css';

const Contact = () => {
    return (
        <section className="section contact-section" id="contact" style={{ textAlign: 'center' }}>
            <div className="container">
                <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                >
                    <h2 className="section-title" style={{ margin: '0 auto 2rem' }}>
                        Every idea has an aura. <br />
                        <span style={{ color: 'var(--text-secondary)' }}>Let’s amplify it.</span>
                    </h2>
                    <p className="big-text" style={{ margin: '0 auto 3rem' }}>
                        Whether it’s a website, brand, campaign, or content — we’ve got you.
                    </p>

                    <a href="mailto:auraofaurac@gmail.com" className="primary-btn">
                        Have an idea? Let’s build it.
                    </a>
                </motion.div>
            </div>
        </section>
    );
};

export default Contact;
