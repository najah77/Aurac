import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Showreel from './components/Showreel';
import About from './components/About';
import Services from './components/Services';
import WhyUs from './components/WhyUs';
import Process from './components/Process';
import Clients from './components/Clients';
import Vibe from './components/Vibe';
import Contact from './components/Contact';
import CursorAura from './components/CursorAura';
import Footer from './components/Footer';

import Marquee from './components/Marquee';

function App() {
  return (
    <div className="app-main">
      <CursorAura />
      <Navbar />
      <Hero />
      <Marquee />
      <Showreel />
      <About />
      <Services />
      <WhyUs />
      <Process />
      <Clients />
      <Vibe />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;
