import React from 'react';
import { motion } from 'framer-motion';
import './Section.css';
import './Process.css';

const Process = () => {
    const steps = [
        { num: '01', title: 'Understand', desc: 'Your brand, goals, and audience' },
        { num: '02', title: 'Design', desc: 'Clean visuals + smart UX' },
        { num: '03', title: 'Build', desc: 'Solid tech & smooth performance' },
        { num: '04', title: 'Launch', desc: 'Go live with confidence' },
        { num: '05', title: 'Grow', desc: 'Optimize, market, and scale' },
    ];

    return (
        <section className="section process-section" id="process">
            <div className="container" style={{ position: 'relative', zIndex: 1 }}>
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="section-header"
                >
                    <span className="section-label">How We Work</span>
                    <h2 className="section-title">Simple process. Zero chaos.</h2>
                </motion.div>

                <div className="process-list">
                    {steps.map((step, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.1 }}
                            className="process-item"
                        >
                            <span className="process-num">{step.num}</span>
                            <div className="process-content">
                                <h3>{step.title}</h3>
                                <p>{step.desc}</p>
                            </div>
                        </motion.div>
                    ))}
                </div>

                {/* Animated Decorative Elements */}
                <motion.div
                    animate={{
                        y: [0, -20, 0],
                        opacity: [0.1, 0.2, 0.1],
                        scale: [1, 1.1, 1]
                    }}
                    transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                    className="white-orb"
                    style={{ top: '10%', right: '5%', width: '400px', height: '400px' }}
                />
                <motion.div
                    animate={{
                        y: [0, 30, 0],
                        opacity: [0.05, 0.15, 0.05],
                        scale: [1, 1.2, 1]
                    }}
                    transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                    className="white-orb"
                    style={{ bottom: '10%', left: '-10%', width: '600px', height: '600px' }}
                />
                <motion.div
                    initial={{ scaleX: 0, opacity: 0 }}
                    whileInView={{ scaleX: 1, opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.5, delay: 0.5 }}
                    className="white-line"
                    style={{ top: '50%', left: 0, width: '100%', height: '1px', transformOrigin: 'left' }}
                />
            </div>
        </section>
    );
};

export default Process;
