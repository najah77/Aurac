import React, { useState, useEffect } from 'react';
import logo from '../assets/logo.png';
import './Navbar.css';

const Navbar = () => {
    const [scrolled, setScrolled] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            setScrolled(window.scrollY > 20);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const scrollToSection = (id) => {
        const element = document.getElementById(id);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    };

    return (
        <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
            <div className="nav-container">
                <div className="nav-logo-wrapper" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
                    <img src={logo} alt="AURAC" className="nav-logo" />
                </div>

                <div className="nav-links">
                    <button onClick={() => scrollToSection('about')} className="nav-link">Who We Are</button>
                    <button onClick={() => scrollToSection('services')} className="nav-link">What We Do</button>
                    <button onClick={() => scrollToSection('process')} className="nav-link">rk</button>
                    <button onClick={() => scrollToSection('contact')} className="nav-cta">Let’s Talk</button>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
