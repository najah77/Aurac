import React from 'react';
import { motion } from 'framer-motion';
import './Services.css';

const Services = () => {
    const services = [
        {
            title: "Build",
            items: ["Website design & development", "Full-stack web apps", "E-commerce solutions", "Front-end & back-end development"],
            desc: "We build fast, scalable, and future-ready products."
        },
        {
            title: "Design",
            items: ["UI / UX design", "Wireframes & prototypes", "Website & app redesigns", "Design systems & aesthetics"],
            desc: "Clean design that feels right — and works better."
        },
        {
            title: "Grow",
            items: ["Social media management", "SEO & organic growth", "Performance marketing & ads", "Content strategy & analytics"],
            desc: "We help brands get seen — by the right people."
        },
        {
            title: "Create",
            items: ["Brand films & ad films", "Video editing & motion graphics", "Product & lifestyle shoots", "Creative direction"],
            desc: "Stories that move. Visuals that stay."
        },
        {
            title: "Brand",
            items: ["Branding & rebranding", "Logo & visual identity", "Brand strategy & positioning", "Campaign concepts"],
            desc: "We don’t just make brands look good — we make them make sense."
        }
    ];

    return (
        <section className="section services-section" id="services">
            <div className="container">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="section-header"
                >
                    <span className="section-label">What We Do</span>
                </motion.div>

                <div className="services-grid">
                    {services.map((service, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            whileHover={{ y: -10, backgroundColor: 'var(--bg-secondary)' }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.1 }}
                            className="service-card"
                        >
                            <h3 className="service-title">{service.title}</h3>
                            <ul className="service-list">
                                {service.items.map((item, i) => (
                                    <li key={i}>{item}</li>
                                ))}
                            </ul>
                            <p className="service-desc">{service.desc}</p>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Services;
