import React from 'react';
import { motion } from 'framer-motion';
import './Section.css';

const Clients = () => {
    const clients = [
        "Startups", "Personal brands", "Businesses & companies", "Creators & founders"
    ];

    return (
        <section className="section clients-section white-theme">
            <div className="container" style={{ position: 'relative', zIndex: 1 }}>
                <div className="clients-content" style={{ display: 'flex', flexDirection: 'column', gap: '4rem' }}>
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                    >
                        <span className="section-label">Who We Work With</span>
                        <h2 className="section-title">
                            If you’re building something meaningful — we’re in.
                        </h2>
                    </motion.div>

                    <motion.ul
                        initial={{ opacity: 0, y: 40 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        style={{ listStyle: 'none', paddingLeft: 0, display: 'flex', flexDirection: 'column' }}
                    >
                        {clients.map((client, index) => (
                            <li key={index} style={{
                                fontSize: 'clamp(1.5rem, 3vw, 2.5rem)',
                                fontWeight: '600',
                                padding: '1.5rem 0',
                                borderBottom: '1px solid rgba(0,0,0,0.1)',
                                letterSpacing: '-0.02em'
                            }}>
                                {client}
                            </li>
                        ))}
                    </motion.ul>
                </div>
            </div>
        </section>
    );
};

export default Clients;
