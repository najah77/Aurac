import React from 'react';
import './BrandLogo.css';

const BrandLogo = ({ variant = 'light' }) => {
    return (
        <div className={`brand-logo ${variant}`}>
            <div className="logo-main">
                <span className="char-a">A</span>
                <span className="char-u">U</span>
                <span className="char-r">R</span>
                <span className="char-a">A</span>
                <span className="char-c">C</span>
            </div>
            <div className="logo-tagline">
                AMPLIFY <span className="the-box">THE</span> AURA
            </div>
        </div>
    );
};

export default BrandLogo;
